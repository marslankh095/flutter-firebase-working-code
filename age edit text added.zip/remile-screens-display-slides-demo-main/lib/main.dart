import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_database/firebase_database.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  FirebaseDatabase.instance.databaseURL =
  "https://kisaa-65c7a-default-rtdb.firebaseio.com/";
  runApp(const MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({super.key});

  @override
  State<MyApp> createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final TextEditingController _displayController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();

  @override
  void initState() {
    super.initState();
    final dbRef = FirebaseDatabase.instance.ref("employees/emp001");

    // Listen to changes in department and age
    dbRef.onValue.listen((event) {
      final data = event.snapshot.value as Map?;
      setState(() {
        if (data != null) {
          final department = data['department'] ?? 'No Department';
          final age = data['age'] ?? 'No Age';
          _displayController.text = "Department: $department\nAge: $age";
        } else {
          _displayController.text = "No Data";
        }
      });
    });
  }

  // Function to update age value in Firebase
  Future<void> _updateAge() async {
    final ageValue = _ageController.text.trim();
    if (ageValue.isEmpty) return;

    try {
      await FirebaseDatabase.instance
          .ref("employees/emp001/age")
          .set(ageValue);

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("✅ Age updated successfully")),
      );
      _ageController.clear();
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Error updating age: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    const double designW = 430.0;
    const double designH = 932.0;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Builder(
        builder: (context) {
          final screenWidth = MediaQuery.of(context).size.width;
          final screenHeight = MediaQuery.of(context).size.height;
          final double scale = (screenWidth / designW < screenHeight / designH)
              ? screenWidth / designW
              : screenHeight / designH;

          return Scaffold(
            body: AnnotatedRegion<SystemUiOverlayStyle>(
              value: SystemUiOverlayStyle.dark,
              child: SafeArea(
                top: false,
                bottom: false,
                child: Stack(
                  children: [
                    // Background image
                    Positioned.fill(
                      child: Image.asset(
                        'assets/other_screen_background.png',
                        fit: BoxFit.cover,
                      ),
                    ),

                    // Back button
                    Positioned(
                      top: 50 * scale,
                      left: 10 * scale,
                      child: IconButton(
                        icon: Icon(
                          Icons.arrow_back_rounded,
                          color: Colors.black,
                          size: 40 * scale,
                        ),
                        onPressed: () {
                          Navigator.of(context).maybePop();
                        },
                      ),
                    ),

                    // Info + Input Container
                    Positioned(
                      top: 250 * scale,
                      left: (designW - 320) / 2 * scale,
                      child: Container(
                        width: 320 * scale,
                        padding: EdgeInsets.all(16 * scale),
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(20 * scale),
                          boxShadow: const [
                            BoxShadow(
                              color: Color.fromRGBO(0, 0, 0, 0.25),
                              blurRadius: 4,
                              offset: Offset(0, 4),
                            ),
                          ],
                        ),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            // Department + Age display
                            TextField(
                              controller: _displayController,
                              readOnly: true,
                              maxLines: 2,
                              decoration: const InputDecoration(
                                labelText: "Employee Info",
                                border: OutlineInputBorder(),
                              ),
                              style: TextStyle(
                                fontSize: 18 * scale,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 20),

                            // Age input
                            TextField(
                              controller: _ageController,
                              keyboardType: TextInputType.number,
                              decoration: const InputDecoration(
                                labelText: "Enter New Age",
                                border: OutlineInputBorder(),
                              ),
                            ),
                            const SizedBox(height: 10),

                            // Update button
                            ElevatedButton(
                              onPressed: _updateAge,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.blueAccent,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 20, vertical: 12),
                              ),
                              child: const Text(
                                "Update Age in Firebase",
                                style: TextStyle(fontSize: 16),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }
}
