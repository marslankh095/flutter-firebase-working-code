package com.example.majh

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
